package com.example.discorddohtest;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private TextView status;
    private Button runButton;

    private static final String DOH_ENDPOINT = "https://cloudflare-dns.com/dns-query";
    private static final String DISCORD_URL = "https://discord.com/app";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(18);
        layout.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("Discord DoH Test");
        title.setTextSize(24);
        title.setTypeface(null, Typeface.BOLD);
        layout.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Cloudflare DNS-over-HTTPS ve Discord HTTPS bağlantı testi");
        subtitle.setTextSize(15);
        LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        subParams.topMargin = dp(8);
        layout.addView(subtitle, subParams);

        runButton = new Button(this);
        runButton.setText("Testleri çalıştır");
        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        btnParams.topMargin = dp(16);
        layout.addView(runButton, btnParams);

        status = new TextView(this);
        status.setTextSize(15);
        status.setText("Hazır. Test için düğmeye dokun.");
        status.setTextIsSelectable(true);
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        statusParams.topMargin = dp(16);
        layout.addView(status, statusParams);

        TextView note = new TextView(this);
        note.setText("\nNot: Bu uygulama VPN değildir ve sistem DNS ayarlarını değiştirmez. "
                + "DoH sorgusunun başarılı olması Discord erişiminin açılacağını garanti etmez.");
        note.setTextSize(13);
        LinearLayout.LayoutParams noteParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        noteParams.topMargin = dp(16);
        layout.addView(note, noteParams);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(layout);
        setContentView(scroll);

        runButton.setOnClickListener(v -> runTests());
    }

    private void runTests() {
        runButton.setEnabled(false);
        status.setText("Testler çalışıyor…\n\n1) Cloudflare DoH DNS sorgusu\n2) Discord HTTPS bağlantısı");
        executor.execute(() -> {
            StringBuilder result = new StringBuilder();
            result.append("Cloudflare DoH: ").append(DOH_ENDPOINT).append("\n\n");

            try {
                String dnsResult = queryCloudflare("discord.com", "A");
                result.append("1. DNS sorgusu (discord.com A)\n")
                      .append(dnsResult).append("\n\n");
            } catch (Exception e) {
                result.append("1. DNS sorgusu başarısız\n")
                      .append(safeMessage(e)).append("\n\n");
            }

            try {
                String httpsResult = testDiscordHttps();
                result.append("2. HTTPS testi (").append(DISCORD_URL).append(")\n")
                      .append(httpsResult).append("\n\n");
            } catch (Exception e) {
                result.append("2. HTTPS testi başarısız\n")
                      .append(safeMessage(e)).append("\n\n");
            }

            result.append("Yorumlama:\n")
                  .append("• DNS başarılı, HTTPS başarısız: DNS çalışıyor olabilir; web bağlantısı yine engelli veya erişilemez olabilir.\n")
                  .append("• DNS başarısız: DoH uç noktası, ağ bağlantısı veya ağ politikası sorunlu olabilir.\n")
                  .append("• Her ikisi başarılı: Sunucuya temel erişim var; Discord oturumu veya diğer servisler yine çalışmayabilir.\n")
                  .append("• Bu testler engeli aşmaz ve sistem genelindeki DNS ayarlarını değiştirmez.");

            final String finalText = result.toString();
            runOnUiThread(() -> {
                status.setText(finalText);
                runButton.setEnabled(true);
            });
        });
    }

    private String queryCloudflare(String name, String type) throws Exception {
        String query = DOH_ENDPOINT + "?name="
                + URLEncoder.encode(name, "UTF-8")
                + "&type=" + URLEncoder.encode(type, "UTF-8");

        HttpURLConnection connection = (HttpURLConnection) new URL(query).openConnection();
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(10000);
        connection.setReadTimeout(10000);
        connection.setRequestProperty("Accept", "application/dns-json");

        try {
            int code = connection.getResponseCode();
            InputStream stream = code >= 200 && code < 400
                    ? connection.getInputStream() : connection.getErrorStream();
            String body = readAll(stream);
            if (code < 200 || code >= 300) {
                return "HTTP " + code + "\n" + body;
            }

            JSONObject json = new JSONObject(body);
            int rcode = json.optInt("Status", -1);
            StringBuilder out = new StringBuilder();
            out.append("HTTP ").append(code)
               .append(", DNS Status=").append(rcode)
               .append(rcode == 0 ? " (NOERROR)" : "");
            JSONArray answers = json.optJSONArray("Answer");
            if (answers != null && answers.length() > 0) {
                out.append("\nYanıtlar:");
                for (int i = 0; i < answers.length(); i++) {
                    JSONObject answer = answers.getJSONObject(i);
                    out.append("\n• ")
                       .append(answer.optString("name", "?"))
                       .append(" → ")
                       .append(answer.optString("data", "?"));
                }
            } else {
                out.append("\nYanıt kaydı yok.");
            }
            return out.toString();
        } finally {
            connection.disconnect();
        }
    }

    private String testDiscordHttps() throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(DISCORD_URL).openConnection();
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(10000);
        connection.setReadTimeout(10000);
        connection.setInstanceFollowRedirects(false);
        connection.setRequestProperty("User-Agent", "DiscordDoHTest/1.0 (Android)");
        try {
            int code = connection.getResponseCode();
            String location = connection.getHeaderField("Location");
            String out = "HTTP " + code + " (" + connection.getResponseMessage() + ")";
            if (location != null) out += "\nYönlendirme: " + location;
            return out;
        } finally {
            connection.disconnect();
        }
    }

    private String readAll(InputStream input) throws Exception {
        if (input == null) return "";
        try (InputStream in = input; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[4096];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    private String safeMessage(Exception e) {
        String message = e.getMessage();
        return e.getClass().getSimpleName() + (message == null ? "" : ": " + message);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdownNow();
    }
}
