# Discord DoH Test (Android)

Bu proje, Cloudflare DNS-over-HTTPS (DoH) sorgusunu ve `https://discord.com/app`
adresine temel HTTPS bağlantısını test eder. VPN değildir; Android sistem DNS
ayarlarını değiştirmez ve erişim engelini aşacağını garanti etmez.

## Android Studio ile APK oluşturma

1. ZIP dosyasını çıkarın.
2. Android Studio'yu açın ve **Open** ile `DiscordDoHTest` klasörünü seçin.
3. Gradle senkronizasyonu istendiğinde tamamlanmasını bekleyin. Gerekirse Android
   SDK Platform 35'i SDK Manager üzerinden yükleyin.
4. Android Studio için JDK olarak **Embedded JDK / JDK 17** kullanın.
5. Menüden **Build > Build Bundle(s) / APK(s) > Build APK(s)** seçin.
6. İşlem tamamlanınca çıkan bildirimde **locate** bağlantısına dokunun.
   APK genellikle `app/build/outputs/apk/debug/app-debug.apk` konumunda olur.
7. APK'yı tablete aktarın. Dosyayı açın; istenirse yalnızca kullandığınız dosya
   yöneticisi/tarayıcı için bu kaynaktan uygulama yükleme izni verin ve yükleyin.

## Test

Uygulamayı açıp **Testleri çalıştır** düğmesine dokunun. Sonuçlar DNS ve HTTPS
testlerini ayrı ayrı gösterir.

## Sorun giderme

- `SDK location not found`: Android Studio > SDK Manager'dan SDK kurun; projeyi
  Android Studio ile açmak çoğu durumda SDK yolunu otomatik yapılandırır.
- Gradle/JDK hatası: Gradle JDK ayarında Embedded JDK (17) seçin.
- `Library file not found`: Bu proje ZIP'ini indirin/çıkarın ve Android Studio'da
  ZIP dosyasını değil, içindeki `DiscordDoHTest` proje klasörünü açın.
- DNS testi başarılı olsa bile Discord uygulamasının çalışacağı garanti değildir.

## APK'yi çevrimiçi derleme (Android Studio kurmadan)

Bu projeye `.github/workflows/build-apk.yml` iş akışı eklendi. GitHub hesabında yeni bir depo oluşturup bu klasördeki dosyaları depoya yükledikten sonra:

1. Depoda **Actions** sekmesini aç.
2. **Build Android APK** iş akışını seç.
3. **Run workflow** düğmesine bas.
4. İşlem tamamlanınca sayfanın altındaki **Artifacts** bölümünden `DiscordDoHTest-debug-apk` dosyasını indir.
5. ZIP arşivini aç; içindeki `app-debug.apk` dosyasını tabletine aktar ve yükle.

Not: Bu işlem GitHub hesabı ve internet erişimi gerektirir. Android, bilinmeyen kaynaklardan uygulama yükleme izni isteyebilir. APK yalnızca test amaçlı debug sürümüdür; Discord'a erişimi garanti etmez.
